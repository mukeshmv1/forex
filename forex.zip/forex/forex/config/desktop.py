# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _

def get_data():
	return [
		{
			"module_name": "Forex",
			"color": "green",
			"icon": "octicon octicon-pulse",
			"type": "module",
			"label": _("Forex")
		}
	]
