// Copyright (c) 2016, FinByz and contributors
// For license information, please see license.txt

frappe.ui.form.on('Outward Tracking', {
	refresh: function(frm) {

	}
});
